
package tda;

import java.util.Scanner;
import java.util.Random;
public class Tda {

    public static void main(String[] args) {
        Scanner entrada= new Scanner (System.in);
        Random rand = new Random();
        int codigo;
        String eleccion; 
        do {
            codigo= rand.nextInt(9000)+1000;
        for (int i=1;i<=10; i++){
            System.out.println("Pastilla " +i +" Empacada");
            
        }
        System.out.println("Codigo de paquete: TRE-"+codigo);
        System.out.println("Desea añadir otro paquete (si/no)");
        eleccion= entrada.nextLine();
        }while ("si".equals(eleccion));
    }
    
}
